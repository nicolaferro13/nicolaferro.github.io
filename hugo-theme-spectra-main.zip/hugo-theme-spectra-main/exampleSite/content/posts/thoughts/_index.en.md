---
title: "Thoughts"
---
